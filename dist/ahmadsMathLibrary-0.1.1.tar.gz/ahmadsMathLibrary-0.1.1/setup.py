from setuptools import setup, find_packages

setup(
    name="ahmadsMathLibrary",
    version="0.1.1",
    packages=["ahmadsMathLibrary"],
    install_requires=[
        "numpy>=1.21.0"
    ]
)
