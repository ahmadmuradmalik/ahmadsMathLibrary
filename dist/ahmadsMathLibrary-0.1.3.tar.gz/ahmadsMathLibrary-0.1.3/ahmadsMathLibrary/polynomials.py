import numpy as np 

"""
This is a module for constructing various kinds of interpolating polynomials. 

1) A few of the potential methods are chebyshev polynomials, lagrange, hermite, 

"""

def chebyshev():
    pass

def Hermite():
    pass

def Lagrange():
    pass

#orthogonal polynomials
def Legendre():
    pass

def chebyshev():
    pass